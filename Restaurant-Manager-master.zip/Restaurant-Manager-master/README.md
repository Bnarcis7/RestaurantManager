# Restaurant-Manager
Microsoft XAML Class Project for WPF in C#
